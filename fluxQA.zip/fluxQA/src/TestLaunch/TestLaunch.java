package TestLaunch;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class TestLaunch {

	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver","C:\\Users\\shrey\\eclipse-workspace\\chromedriver.exe");
    	
    	WebDriver driver=new ChromeDriver();// TODO Auto-generated method stub
    	driver.get("https://www.google.com");

	}

}
