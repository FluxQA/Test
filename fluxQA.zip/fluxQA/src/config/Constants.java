package config;

public class Constants {

    //List of System Variables
    public static final String URL = "http://demo.guru99.com/V4/";
    public static final String Path_TestData = "C://Users//shrey//eclipse-workspace2//fluxQA//src//dataEngine//DataEngine.xls";
    public static final String Path_OR = "C://Users//shrey//eclipse-workspace2//fluxQA//src//config//OR.txt";
    
    public static final String File_TestData = "DataEngine.xls";
    public static final int Col_Result =3 ;
    public static final int Col_TestStepResult =6 ;
    public static final String KEYWORD_FAIL = "FAIL";
    public static final String KEYWORD_PASS = "PASS";
    //List of Data Sheet Column Numbers
    public static final int Col_TestCaseID = 0; 
    public static final int Col_TestScenarioID =1 ;
    public static final int Col_PageObject =3 ;
    public static final int Col_ActionKeyword =4 ;
    public static final int Col_DataSet =5 ;
    //public static final int Col_TestStepResult =6 ;
    //New entry in Constant variable
    public static final int Col_RunMode =2 ;

    //List of Data Engine Excel sheets
    public static final String Sheet_TestSteps = "Test Steps";
    //New entry in Constant variable
    public static final String Sheet_TestCases = "Test Cases";

    //List of Test Data
    public static final String UserName = "testuser";
    public static final String Password = "Shrey@123";

}
