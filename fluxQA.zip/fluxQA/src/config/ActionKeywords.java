package config;

import static executionEngine.DriverScript.OR;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.apache.http.util.Asserts;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.support.ui.Select;



import executionEngine.DriverScript;
import utility.Log;



public class ActionKeywords {
	 
	
	public static WebDriver driver;
    //This block of code will decide which browser type to start
    public static void openBrowser(String object,String data) throws IOException {      
        Log.info("Opening Browser");
        System.out.println("openB");
        try{
          //  If value of the parameter is Mozilla, this will execute
          if(data.equals("Mozilla")){
                driver=new FirefoxDriver();
                Log.info("Mozilla browser started");
                }
            else if(data.equals("IE")){
                //You may need to change the code here to start IE Driver
            	System.setProperty("webdriver.ie.driver","C:\\IEDriverServer.exe");
            	System.out.println("IE");
                driver=new InternetExplorerDriver();
                Log.info("IE browser started");
                }
            else if(data.equals("Chrome")){
            	//System.out.println("insidehrome");
            	System.setProperty("webdriver.chrome.driver","C:\\chromedriver.exe");
            	//System.out.println("prop");
            	//System.out.println(System.getProperty("webdriver.chrome.driver"));
            	driver=new ChromeDriver();
            	
                Log.info("Chrome browser started");
                               
                }
            System.out.println("browser initiated");
            DriverScript.bResult = true;
            int implicitWaitTime=(10);
           driver.manage().timeouts().implicitlyWait(implicitWaitTime, TimeUnit.SECONDS);
        } 
          catch (Exception e){
            Log.info("Not able to open the Browser --- " + e.getMessage());
            DriverScript.bResult = false;
            captureScreenshot(object);
        }
    }

    public static void navigate(String object, String data){
        try{
            Log.info("Navigating to URL");
            driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
            driver.manage().window().maximize();
            //Constant Variable is used in place of URL
            driver.get(data);
            DriverScript.bResult = true;
        }catch(Exception e){
            Log.info("Not able to navigate --- " + e.getMessage());
            DriverScript.bResult = false;
            captureScreenshot(object);
            }
        }

    public static void click(String object, String data){
        try{
            Log.info("Clicking on Webelement "+ object);
            driver.findElement(By.xpath(OR.getProperty(object))).click();
            DriverScript.bResult = true;
         }  catch(Exception e){
        	captureScreenshot(object);
            Log.error("Not able to click --- " + e.getMessage());
            DriverScript.bResult = false;
            }
        }
    
           public static void captureScreenshot(String object) {
    	  	try{
            Log.info("Capture Screenshot"+ object);
            File scrFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
            FileUtils.copyFile(scrFile, new File("C:\\Users\\shrey\\eclipse-workspace2\\fluxQA\\target\\testoutputs\\Failed_Screenshots\\Scrrenshot.png"));
                       
          
         }catch(Exception e){
            Log.error("Not able to capture screenshot --- " + e.getMessage());
            DriverScript.bResult = false;
            }
        }
    	    	
    
    
    public static void checkboxSelect (String object, String data) {
    	try {
    		Log.info("Selecting Checkbox" + object);
    		if (!driver.findElement(By.xpath(OR.getProperty(object))).isSelected());
    		  {
    			  driver.findElement(By.xpath(OR.getProperty(object))).click();
    			  
    		  }
    	}	  catch(Exception e){
    	            Log.error("Not able to select --- " + e.getMessage());
    	            DriverScript.bResult = false;
    	            captureScreenshot(object);
    	            }
    	
    }
    
    public static void dropdown (String object, String data) {
    	try {
    		Log.info("Selecting dropdown values" + object);
    		new Select(driver.findElement(By.xpath(OR.getProperty(object)))).selectByVisibleText(data)	;
    		Thread.sleep(1000);
    			  //
    	//driver.findElement(By.id(OR.getProperty(object))).c();
    		//dropdown.selectByValue(OR.getProperty(data));	
    /*		
    		Select drpdown = new Select (driver.findElement(By.xpath(OR.getProperty(object))));
    		Thread.sleep(3000);
    		drpdown.selectByVisibleText(data);*/
    		
    		
    		System.out.println(data);
    		  
    	}	  catch(Exception e){
    	            Log.error("Not able to select --- " + e.getMessage());
    	            DriverScript.bResult = false;
    	            captureScreenshot(object);
    	            }
    	
    }
    
    public static void input(String object, String data){
        try{
            Log.info("Entering the text in " + object);
            driver.findElement(By.xpath(OR.getProperty(object))).sendKeys(data);
            DriverScript.bResult = true;
         }catch(Exception e){
             Log.error("Not able to Enter UserName --- " + e.getMessage());
             DriverScript.bResult = false;
             captureScreenshot(object);
            }
        }

    public static void waitFor(String object, String data) throws Exception{
        try{
            Log.info("Wait for 5 seconds");
            Thread.sleep(5000);
            DriverScript.bResult = true;
         }catch(Exception e){
             Log.error("Not able to Wait --- " + e.getMessage());
             DriverScript.bResult = false;
            }
        }

    
    public static void verifyTitle(String object, String data){	
    	
        try {
    		Log.info("Validate Title" + object);
    		Thread.sleep(5000);
        	String actualTitle = driver.getTitle();
        	//System.out.println(actualTitle);
        	Log.info(" Title" + actualTitle);
            String expectedTitle = OR.getProperty(object);
           Log.info(" Expected Title" + OR.getProperty(object));
                       
    		
    		if (expectedTitle != actualTitle) {
    			 
    			 DriverScript.bResult = false;
    			 Log.error("Not able to validate/incorrect Title --- " );
    			 captureScreenshot(object);
    			 System.out.println(DriverScript.bResult);
    			 
    		}
    			
    		if (expectedTitle.equals(actualTitle)) 
			{
			  DriverScript.bResult = true;
			  Log.info("Correct Title");   			      	  
			}
    		}
        catch(Exception e){
    			 Log.error ("Not able to validate/incorrect Title --- " + object + e.getMessage());
    	         DriverScript.bResult = false;
    	         captureScreenshot(object);
    	     }  		
    }
    
    public static void getList_Verify(String object, String data) {
    	try {
    		Log.info("Get Text");
    	List<WebElement> elements =	driver.findElements(By.xpath(OR.getProperty(object)));
    	for (WebElement e : elements) {
    		Log.info(e.getText());
    		String actualList= e.getText();
    		String expectedList = OR.getProperty(object);
    		
    		if (expectedList.equals(actualList))
  		  {
  			  DriverScript.bResult = true;
  			    			  
  		  }
    		
    		//	e.click();
    	}
    	
    	//DriverScript.bResult = true;
          }catch(Exception e){
             Log.error("Not able to validate --- " + e.getMessage());
             DriverScript.bResult = false;
             captureScreenshot(object);
             }
    		
    	}
    
    public static void verifyText(String object, String data) {
    	try {
    	Log.info("Validate Text" + object);
		Thread.sleep(500);
    	String actualText = driver.findElement(By.xpath(OR.getProperty(object))).getText();
    	System.out.println(actualText);
    	Log.info(" Text" + actualText);
        String expectedText = OR.getProperty(object);
       Log.info(" Exp Text" + OR.getProperty(object));
                   
		if (expectedText.equals(actualText))
		  {
			  DriverScript.bResult = true;
			  
			    }
		else {
			DriverScript.bResult = false;
			captureScreenshot(object);
		}
	}	  catch(Exception e){
	            Log.error("Not able to validate/incorrect Text --- " + object + e.getMessage()  );
	            DriverScript.bResult = false;
	            captureScreenshot(object);
	            }
    }
    
    public static void closeBrowser(String object, String data){
        try{
            Log.info("Closing the browser");
            driver.quit();
            DriverScript.bResult = true;
         }catch(Exception e){
             Log.error("Not able to Close the Browser --- " + e.getMessage());
             DriverScript.bResult = false;
             captureScreenshot(object);
            }
        }

    }




	